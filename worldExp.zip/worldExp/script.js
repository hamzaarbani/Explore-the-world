document.addEventListener('DOMContentLoaded', function() {
    // Tab functionality
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all buttons and contents
            tabBtns.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked button and corresponding content
            btn.classList.add('active');
            const tabId = btn.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // Search functionality
    const searchBtn = document.getElementById('search-btn');
    const countrySearch = document.getElementById('country-search');

    searchBtn.addEventListener('click', searchCountry);
    countrySearch.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchCountry();
        }
    });

    // Sample data (in a real app, you would fetch from an API)
    const countryData = {
    'france': {
        name: 'France',
        flag: 'https://flagcdn.com/w320/fr.png',
        overview: 'France, in Western Europe, encompasses medieval cities, alpine villages and Mediterranean beaches. Paris, its capital, is famed for its fashion houses, classical art museums including the Louvre and monuments like the Eiffel Tower.',
        population: '67 million',
        language: 'French',
        currency: 'Euro (€)',
        capital: 'Paris',
        cities: [
            { name: 'Paris', image: 'https://images.unsplash.com/photo-1431274172761-fca41d930114?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'The capital and most populous city of France.' },
            { name: 'Marseille', image: 'https://images.unsplash.com/photo-1526815456940-2c11653292a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'A major French port city on the Mediterranean coast.' },
            { name: 'Lyon', image: 'https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Known for its historical and architectural landmarks.' },
            { name: 'Nice', image: 'https://images.unsplash.com/photo-1522093007474-d86e9bf7ba6f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Famous for its stunning beaches and vibrant culture.' }
        ],
        laws: [
            { title: 'Secularism Law', description: 'France has strict secularism laws that prohibit the display of conspicuous religious symbols in public schools and government buildings.' },
            { title: 'Smoking Ban', description: 'Smoking is banned in all indoor public places including restaurants, bars, and offices.' },
            { title: 'Plastic Ban', description: 'Single-use plastic items like plates, cups, and cutlery are banned in France.' }
        ],
        locations: [
            { name: 'Eiffel Tower', image: 'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Iconic iron tower in Paris, one of the most recognized structures in the world.' },
            { name: 'Louvre Museum', image: 'images/Mes.jpg', description: 'World\'s largest art museum and a historic monument in Paris.' },
            { name: 'Mont Saint-Michel', image: 'images/fra.jpg', description: 'Island commune in Normandy, known for its medieval architecture.' },
            { name: 'Provence Lavender Fields', image: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Beautiful purple lavender fields in the Provence region.' }
        ],
        cuisine: [
            { name: 'Croissant', image: 'https://images.unsplash.com/photo-1587814213271-7a6625b76c33?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Buttery, flaky pastry of Austrian origin, but associated with France.' },
            { name: 'Bouillabaisse', image: 'https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Traditional Provençal fish stew originating from Marseille.' },
            { name: 'Coq au Vin', image: 'https://images.unsplash.com/photo-1603105037880-880cd4edfb0d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Chicken braised with wine, mushrooms, and garlic.' },
            { name: 'Crêpe', image: 'images/crepe.jpg', description: 'Very thin pancake that can be sweet or savory.' }
        ]
    },
    'japan': {
        name: 'Japan',
        flag: 'https://flagcdn.com/w320/jp.png',
        overview: 'Japan is an island country in East Asia known for its dense cities, imperial palaces, mountainous national parks and thousands of shrines and temples. Tokyo, the capital, is known for skyscrapers, shopping and pop culture.',
        population: '126 million',
        language: 'Japanese',
        currency: 'Yen (¥)',
        capital: 'Tokyo',
        cities: [
            { name: 'Tokyo', image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Japan\'s busy capital, mixing the ultramodern and the traditional.' },
            { name: 'Kyoto', image: 'https://images.unsplash.com/photo-1492571350019-22de08371fd3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Former capital known for its classical Buddhist temples and gardens.' },
            { name: 'Osaka', image: 'https://images.unsplash.com/photo-1563492065599-3520f775eeed?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Large port city known for its modern architecture and vibrant nightlife.' },
            { name: 'Hiroshima', image: 'images/herosima.jpg', description: 'City rebuilt after being destroyed by an atomic bomb in WWII.' }
        ],
        laws: [
            { title: 'Drug Laws', description: 'Japan has extremely strict drug laws with severe penalties for possession or use of illegal substances.' },
            { title: 'Smoking Regulations', description: 'Smoking is banned on many streets in Tokyo and other cities, with designated smoking areas provided.' },
            { title: 'Gambling Laws', description: 'Most forms of gambling are illegal in Japan, with exceptions for certain sports and pachinko.' }
        ],
        locations: [
            { name: 'Mount Fuji', image: 'https://images.unsplash.com/photo-1589308078059-be1415eab4c3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Japan\'s tallest mountain and active volcano, iconic symbol of Japan.' },
            { name: 'Fushimi Inari Shrine', image: 'https://images.unsplash.com/photo-1452421822248-d4c2b47f0c81?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Famous for its thousands of vermilion torii gates in Kyoto.' },
            { name: 'Tokyo Skytree', image: 'https://images.unsplash.com/photo-1528164344705-47542687000d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Tallest structure in Japan and second tallest in the world at the time of its completion.' },
            { name: 'Arashiyama Bamboo Grove', image: 'images/bamboo.jpg', description: 'Beautiful bamboo forest in Kyoto that creates a mesmerizing atmosphere.' }
        ],
        cuisine: [
            { name: 'Sushi', image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Vinegared rice combined with various ingredients, primarily seafood.' },
            { name: 'Ramen', image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Wheat noodles served in a meat or fish-based broth with various toppings.' },
            { name: 'Tempura', image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Seafood or vegetables that have been battered and deep fried.' },
            { name: 'Matcha Desserts', image: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Various desserts made with powdered green tea, from ice cream to cakes.' }
        ]
    },
    'pakistan': {
        name: 'Pakistan',
        flag: 'images/pak_flag.jpg',
        overview: 'Pakistan, officially the Islamic Republic of Pakistan, is a country in South Asia. It\'s the world\'s fifth-most populous country with a rich cultural heritage and diverse landscapes ranging from coastal areas to mountains.',
        population: '225 million',
        language: 'Urdu, English',
        currency: 'Pakistani Rupee (₨)',
        capital: 'Islamabad',
        cities: [
            { name: 'Karachi', image: 'images/karachi.jpg', description: 'Largest city and financial hub of Pakistan with a vibrant cultural scene.' },
            { name: 'Lahore', image: 'images/lahore.jpg', description: 'Cultural heart of Pakistan known for its Mughal architecture and food.' },
            { name: 'Islamabad', image: 'images/islamabad.jpg', description: 'Modern capital city at the foothills of the Himalayas.' },
            { name: 'Peshawar', image: 'images/peshawar.jpeg', description: 'Ancient city with a rich history as a crossroads of civilizations.' }
        ],
        laws: [
            { title: 'Islamic Law', description: 'Pakistan follows a mixed legal system of English common law and Islamic law (Sharia) for certain matters.' },
            { title: 'Blasphemy Laws', description: 'Pakistan has strict blasphemy laws that prohibit derogatory remarks against Islamic beliefs.' },
            { title: 'Drug Laws', description: 'Possession and trafficking of narcotics are punishable by severe penalties including life imprisonment.' }
        ],
        locations: [
            { name: 'K2 Mountain', image: 'images/k2.jpg', description: 'Second highest mountain in the world located in the Karakoram range.' },
            { name: 'Badshahi Mosque', image: 'images/badshahi.jpg', description: 'Iconic Mughal-era mosque in Lahore, one of Pakistan\'s most famous landmarks.' },
            { name: 'Hunza Valley', image: 'images/Hunza.jpg', description: 'Stunning mountainous valley known for its beauty and hospitality.' },
            { name: 'Mohenjo-Daro', image: 'images/moheh.jpg', description: 'Archaeological site of the ancient Indus Valley Civilization.' }
        ],
        cuisine: [
            { name: 'Biryani', image: 'images/biryani.jpg', description: 'Fragrant rice dish cooked with spices and meat, a staple of Pakistani cuisine.' },
            { name: 'Nihari', image: 'images/nehari.jpeg', description: 'Slow-cooked meat stew traditionally eaten for breakfast.' },
            { name: 'Haleem', image: 'images/haleem.jpeg', description: 'Thick stew of wheat, barley, meat and lentils, popular during Ramadan.' },
            { name: 'Chapli Kebab', image: 'images/kabab.jpeg', description: 'Spiced minced meat patty, a specialty of Khyber Pakhtunkhwa province.' }
        ]
    },
    'india': {
        name: 'India',
        flag: 'images/india.jpg',
        overview: 'India is a vast South Asian country with diverse terrain - from Himalayan peaks to Indian Ocean coastline - and history reaching back 5 millennia. It\'s known for its vibrant culture, numerous languages, and as the birthplace of major religions.',
        population: '1.4 billion',
        language: 'Hindi, English',
        currency: 'Indian Rupee (₹)',
        capital: 'New Delhi',
        cities: [
            { name: 'Mumbai', image: 'images/Mumbai.jpg', description: 'Financial capital of India and home to Bollywood film industry.' },
            { name: 'Delhi', image: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Capital territory containing New Delhi, with historical sites from multiple empires.' },
            { name: 'Bangalore', image: 'https://images.unsplash.com/photo-1529253355930-ddbe423a2ac7?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'India\'s tech hub known as the "Silicon Valley of India".' },
            { name: 'Jaipur', image: 'https://images.unsplash.com/photo-1477587458883-47145ed94245?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Capital of Rajasthan known as the "Pink City" for its colored buildings.' }
        ],
        laws: [
            { title: 'Constitutional Secularism', description: 'India is constitutionally secular with equal treatment of all religions, despite its Hindu majority.' },
            { title: 'LGBTQ Rights', description: 'Homosexuality was decriminalized in 2018, though same-sex marriage is not recognized.' },
            { title: 'Environmental Laws', description: 'India has strict environmental protection laws including wildlife protection and pollution control acts.' }
        ],
        locations: [
            { name: 'Taj Mahal', image: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Iconic white marble mausoleum in Agra, one of the New Seven Wonders of the World.' },
            { name: 'Varanasi', image: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Ancient holy city on the Ganges River, sacred in Hinduism.' },
            { name: 'Goa Beaches', image: 'https://images.unsplash.com/photo-1526488807855-309186804587?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Famous beaches and Portuguese-influenced architecture in this coastal state.' },
            { name: 'Kerala Backwaters', image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Network of brackish lagoons and lakes parallel to the Arabian Sea coast.' }
        ],
        cuisine: [
            { name: 'Butter Chicken', image: 'https://images.unsplash.com/photo-1585938389612-a552a28d6914?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Creamy tomato-based curry with tandoori chicken pieces.' },
            { name: 'Biryani', image: 'https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Fragrant rice dish cooked with spices and meat, with regional variations.' },
            { name: 'Masala Dosa', image: 'https://images.unsplash.com/photo-1585314062604-1a357de8b000?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Thin, crispy rice pancake filled with spiced potatoes, from South India.' },
            { name: 'Chaat', image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Umbrella term for savory snacks typically sold at roadside stalls.' }
        ]
    },
    'usa': {
        name: 'United States',
        flag: 'images/us.jpg',
        overview: 'The U.S. is a country of 50 states covering a vast swath of North America, with Alaska in the northwest and Hawaii extending the nation\'s presence into the Pacific Ocean. Major cities include New York, Los Angeles, and Chicago.',
        population: '331 million',
        language: 'English',
        currency: 'US Dollar ($)',
        capital: 'Washington, D.C.',
        cities: [
            { name: 'New York City', image: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Most populous U.S. city known for finance, culture, and landmarks like Times Square.' },
            { name: 'Los Angeles', image: 'images/los.jpg', description: 'Entertainment capital of the world, home to Hollywood.' },
            { name: 'Chicago', image: 'https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Midwestern metropolis known for architecture and deep-dish pizza.' },
            { name: 'Las Vegas', image: 'https://images.unsplash.com/photo-1589487391730-58f20eb2c308?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Famous for its vibrant nightlife centered around casinos and shows.' }
        ],
        laws: [
            { title: 'Constitutional Rights', description: 'The U.S. Constitution guarantees fundamental rights like freedom of speech, religion, and the press.' },
            { title: 'Gun Laws', description: 'The Second Amendment protects the right to bear arms, with varying state regulations.' },
            { title: 'Healthcare System', description: 'The U.S. has a mixed public-private healthcare system without universal coverage.' }
        ],
        locations: [
            { name: 'Grand Canyon', image: 'https://images.unsplash.com/photo-1509316785289-025f5b846b35?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Massive canyon carved by the Colorado River in Arizona.' },
            { name: 'Statue of Liberty', image: 'images/lib.jpg', description: 'Iconic symbol of freedom in New York Harbor, gift from France.' },
            { name: 'Yellowstone National Park', image: 'https://images.unsplash.com/photo-1581434681675-5b088a708b1f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'First national park in the world known for geothermal features and wildlife.' },
            { name: 'Golden Gate Bridge', image: 'https://images.unsplash.com/photo-1508804185872-d7badad00f7d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Suspension bridge connecting San Francisco to Marin County.' }
        ],
        cuisine: [
            { name: 'Hamburger', image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Sandwich consisting of a cooked ground meat patty, usually beef.' },
            { name: 'BBQ Ribs', image: 'https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Pork or beef ribs slow-cooked and basted with barbecue sauce.' },
            { name: 'Apple Pie', image: 'https://images.unsplash.com/photo-1562007908-859b4ba9a1a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Dessert pastry with apple filling, considered quintessentially American.' },
            { name: 'Tex-Mex', image: 'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Americanized Mexican cuisine including tacos, burritos, and nachos.' }
        ]
    },
        'italy': {
            name: 'Italy',
            flag: 'https://flagcdn.com/w320/it.png',
            overview: 'Italy, a European country with a long Mediterranean coastline, has left a powerful mark on Western culture and cuisine. Its capital, Rome, is home to the Vatican as well as landmark art and ancient ruins.',
            population: '60 million',
            language: 'Italian',
            currency: 'Euro (€)',
            capital: 'Rome',
            cities: [
                { name: 'Rome', image: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'The capital with ancient ruins like the Colosseum and the Roman Forum.' },
                { name: 'Venice', image: 'https://images.unsplash.com/photo-1514890547357-a9ee288728e0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Famous for its canals, gondolas, and beautiful architecture.' },
                { name: 'Florence', image: 'https://images.unsplash.com/photo-1492962827063-e5ea0d8c01f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Renowned for its art and architecture from the Renaissance period.' },
                { name: 'Milan', image: 'https://images.unsplash.com/photo-1610019085766-c48a0e2b93f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Global capital of fashion and design with a rich artistic heritage.' }
            ],
            laws: [
                { title: 'Smoking Ban', description: 'Smoking is banned in all indoor public places including bars and restaurants.' },
                { title: 'Plastic Reduction', description: 'Italy has banned certain single-use plastic items to reduce pollution.' },
                { title: 'Heritage Protection', description: 'Strict laws protect Italy\'s vast cultural heritage and historical sites.' }
            ],
            locations: [
                { name: 'Colosseum', image: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Ancient amphitheater in Rome that could hold over 50,000 spectators.' },
                { name: 'Leaning Tower of Pisa', image: 'https://images.unsplash.com/photo-1553615736-5e5c48f469b5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Famous for its unintended tilt, located in the city of Pisa.' },
                { name: 'Venice Canals', image: 'https://images.unsplash.com/photo-1514890547357-a9ee288728e0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Network of canals that form the streets of Venice, traveled by gondolas.' },
                { name: 'Cinque Terre', image: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Colorful coastal villages along the Italian Riviera.' }
            ],
            cuisine: [
                { name: 'Pizza', image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Flatbread topped with tomato sauce, cheese, and various toppings, baked in an oven.' },
                { name: 'Pasta', image: 'https://images.unsplash.com/photo-1555949258-eb67b1ef0ceb?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Staple food made from unleavened dough with numerous varieties.' },
                { name: 'Gelato', image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Italian version of ice cream, made with milk, cream, sugar and flavorings.' },
                { name: 'Tiramisu', image: 'https://images.unsplash.com/photo-1535920527002-b35e96722eb9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60', description: 'Coffee-flavored dessert made with ladyfingers dipped in coffee, layered with whipped mixture of eggs, sugar and mascarpone.' }
            ]
        }
    };

    function searchCountry() {
        const searchTerm = countrySearch.value.trim().toLowerCase();
        
        if (searchTerm === '') {
            alert('Please enter a country name');
            return;
        }

        if (countryData[searchTerm]) {
            displayCountry(countryData[searchTerm]);
        } else {
            alert('Country not found in our database. Try France, Japan, or Italy for demo purposes.');
        }
    }

    function displayCountry(country) {
        // Update basic info
        document.getElementById('country-name').textContent = country.name;
        document.getElementById('country-flag').src = country.flag;
        document.getElementById('country-flag').alt = `Flag of ${country.name}`;
        document.getElementById('country-overview').textContent = country.overview;
        document.getElementById('population').textContent = `Population: ${country.population}`;
        document.getElementById('language').textContent = `Language: ${country.language}`;
        document.getElementById('currency').textContent = `Currency: ${country.currency}`;
        document.getElementById('capital').textContent = `Capital: ${country.capital}`;

        // Display cities
        const citiesContainer = document.getElementById('cities-container');
        citiesContainer.innerHTML = '';
        country.cities.forEach(city => {
            citiesContainer.innerHTML += `
                <div class="city-card">
                    <img src="${city.image}" alt="${city.name}" class="city-img">
                    <div class="city-info">
                        <h3>${city.name}</h3>
                        <p>${city.description}</p>
                    </div>
                </div>
            `;
        });

        // Display laws
        const lawsContainer = document.getElementById('laws-container');
        lawsContainer.innerHTML = '';
        country.laws.forEach(law => {
            lawsContainer.innerHTML += `
                <div class="law-item">
                    <h3>${law.title}</h3>
                    <p>${law.description}</p>
                </div>
            `;
        });

        // Display locations
        const locationsContainer = document.getElementById('locations-container');
        locationsContainer.innerHTML = '';
        country.locations.forEach(location => {
            locationsContainer.innerHTML += `
                <div class="location-card">
                    <img src="${location.image}" alt="${location.name}" class="location-img">
                    <div class="location-info">
                        <h3>${location.name}</h3>
                        <p>${location.description}</p>
                    </div>
                </div>
            `;
        });

        // Display cuisine
        const cuisineContainer = document.getElementById('cuisine-container');
        cuisineContainer.innerHTML = '';
        country.cuisine.forEach(dish => {
            cuisineContainer.innerHTML += `
                <div class="cuisine-card">
                    <img src="${dish.image}" alt="${dish.name}" class="cuisine-img">
                    <div class="cuisine-info">
                        <h3>${dish.name}</h3>
                        <p>${dish.description}</p>
                    </div>
                </div>
            `;
        });

        // Activate the overview tab
        document.querySelector('.tab-btn[data-tab="overview"]').click();
    }

    // Initialize with France as default
    displayCountry(countryData['france']);
});